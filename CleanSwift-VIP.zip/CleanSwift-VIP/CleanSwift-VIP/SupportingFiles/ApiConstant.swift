//
//  ApiConstant.swift
//  CleanSwift-VIP
//
//  Created by Muhammad Salman on 04/09/2022.
//

import Foundation

let API_KEY = "aTB1I4G5YP7OwFjjmDczE1Cz0EX3LI5z"

let BASE_URL = "https://api.nytimes.com/"
